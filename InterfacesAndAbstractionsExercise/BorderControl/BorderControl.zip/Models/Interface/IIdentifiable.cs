﻿namespace BorderControl.Models.Interface
{
	public interface IIdentifiable
	{
		public string Id { get; }
	}
}