﻿namespace BirthdayCelebrations.Models.Interfaces
{
	public interface IIdentifiable
	{
		public string Id { get; }
	}
}